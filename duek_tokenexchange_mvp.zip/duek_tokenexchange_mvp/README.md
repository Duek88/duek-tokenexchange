# DUEK TokenExchange MVP (Scaffold)

This is a lightweight MVP scaffold (frontend + backend + contracts) you can upload to GitHub directly from your iPhone.

## What's inside
- `backend/` Node.js + Express API (mocked in-memory orderbook)
- `frontend/` React (Vite) UI to view/create orders
- `contracts/` Solidity placeholder contracts (ERC20 + asset token)

## Quick start (local dev)
1) Backend
```bash
cd backend
npm install
npm run dev
```

2) Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend expects backend on `http://localhost:8080`.

## Deploy notes
This is a starter. You can later connect a real database, wallet auth, and on-chain settlement.
