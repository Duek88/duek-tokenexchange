import React, { useEffect, useMemo, useState } from "react";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8080";

export default function App() {
  const [token, setToken] = useState("DUEK-RE-001");
  const [orders, setOrders] = useState([]);
  const [side, setSide] = useState("buy");
  const [price, setPrice] = useState(100);
  const [amount, setAmount] = useState(1);
  const [status, setStatus] = useState("");

  const load = async () => {
    setStatus("Loading...");
    try {
      const r = await fetch(`${API_BASE}/api/orders?token=${encodeURIComponent(token)}`);
      const j = await r.json();
      setOrders(j.orders || []);
      setStatus("");
    } catch (e) {
      setStatus("Failed to load. Check backend URL.");
    }
  };

  useEffect(() => { load(); }, [token]);

  const submit = async (e) => {
    e.preventDefault();
    setStatus("Submitting...");
    try {
      const r = await fetch(`${API_BASE}/api/orders`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ side, token, price: Number(price), amount: Number(amount) }),
      });
      if (!r.ok) {
        const t = await r.text();
        throw new Error(t);
      }
      setPrice(100); setAmount(1);
      await load();
      setStatus("✅ Order added");
      setTimeout(() => setStatus(""), 1200);
    } catch (e) {
      setStatus("❌ Submit failed");
    }
  };

  const remove = async (id) => {
    setStatus("Removing...");
    try {
      await fetch(`${API_BASE}/api/orders/${id}`, { method: "DELETE" });
      await load();
      setStatus("");
    } catch {
      setStatus("❌ Remove failed");
    }
  };

  return (
    <div style={{ fontFamily: "system-ui", maxWidth: 860, margin: "24px auto", padding: 16 }}>
      <h1>DUEK TokenExchange MVP</h1>
      <p style={{ opacity: 0.75 }}>API: {API_BASE}</p>

      <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <label>
          Token:
          <input value={token} onChange={(e) => setToken(e.target.value)} style={{ marginLeft: 8 }} />
        </label>
        <button onClick={load}>Refresh</button>
        <span>{status}</span>
      </div>

      <hr style={{ margin: "20px 0" }} />

      <h2>Create Order</h2>
      <form onSubmit={submit} style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
        <label>
          Side:
          <select value={side} onChange={(e) => setSide(e.target.value)} style={{ marginLeft: 8 }}>
            <option value="buy">buy</option>
            <option value="sell">sell</option>
          </select>
        </label>
        <label>
          Price:
          <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} style={{ marginLeft: 8, width: 120 }} />
        </label>
        <label>
          Amount:
          <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ marginLeft: 8, width: 120 }} />
        </label>
        <button type="submit">Add</button>
      </form>

      <hr style={{ margin: "20px 0" }} />

      <h2>Order Book (in-memory)</h2>
      <div style={{ overflowX: "auto" }}>
        <table width="100%" cellPadding="8" style={{ borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ textAlign: "left", borderBottom: "1px solid #ccc" }}>
              <th>ID</th><th>Side</th><th>Token</th><th>Price</th><th>Amount</th><th>Created</th><th></th>
            </tr>
          </thead>
          <tbody>
            {orders.map(o => (
              <tr key={o.id} style={{ borderBottom: "1px solid #eee" }}>
                <td>{o.id}</td>
                <td>{o.side}</td>
                <td>{o.token}</td>
                <td>{o.price}</td>
                <td>{o.amount}</td>
                <td style={{ opacity: 0.7 }}>{new Date(o.createdAt).toLocaleString()}</td>
                <td><button onClick={() => remove(o.id)}>Delete</button></td>
              </tr>
            ))}
            {!orders.length && (
              <tr><td colSpan="7" style={{ opacity: 0.7, padding: 16 }}>No orders yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
