# Contracts (placeholder)

This folder contains starter Solidity contracts you can extend.

- `ERC20Mock.sol`: basic ERC20 for testing
- `RealEstateAssetToken.sol`: placeholder for asset-backed token idea

You can later add Hardhat/Foundry setup here.
