import express from "express";
import cors from "cors";
import { z } from "zod";

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8080;
const CORS_ORIGIN = process.env.CORS_ORIGIN || "http://localhost:5173";
app.use(cors({ origin: CORS_ORIGIN }));

/**
 * In-memory orderbook (MVP)
 * order: { id, side: "buy"|"sell", token, price, amount, createdAt }
 */
const orders = [];
let nextId = 1;

const OrderSchema = z.object({
  side: z.enum(["buy", "sell"]),
  token: z.string().min(1),
  price: z.number().positive(),
  amount: z.number().positive(),
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/api/orders", (req, res) => {
  const token = (req.query.token || "").toString();
  const filtered = token ? orders.filter(o => o.token === token) : orders;
  res.json({ orders: filtered.sort((a,b) => b.id - a.id) });
});

app.post("/api/orders", (req, res) => {
  const parsed = OrderSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() });
  }
  const order = {
    id: nextId++,
    ...parsed.data,
    createdAt: new Date().toISOString(),
  };
  orders.push(order);
  res.status(201).json({ order });
});

app.delete("/api/orders/:id", (req, res) => {
  const id = Number(req.params.id);
  const idx = orders.findIndex(o => o.id === id);
  if (idx === -1) return res.status(404).json({ error: "Not found" });
  const [removed] = orders.splice(idx, 1);
  res.json({ removed });
});

app.listen(PORT, () => {
  console.log(`API listening on :${PORT}`);
});
